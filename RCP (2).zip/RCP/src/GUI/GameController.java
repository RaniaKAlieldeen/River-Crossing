package GUI;

import Controllers.ICrosser;
import Controllers.IRiverCrossingController;
import Controllers.IcrossingStrategy;
import Stories.*;
import java.util.ArrayList;
import java.util.List;

public class GameController implements IRiverCrossingController {

    IcrossingStrategy str;
    private int numberOfSails = 0;
    private boolean isOnLeftBank = true;
    private List<ICrosser> boatCrossers = new ArrayList<ICrosser>();

    @Override
    public void newGame(IcrossingStrategy gameStrategy) {
        str = gameStrategy;
    }

    @Override
    public void resetGame() {
        this.numberOfSails = 0;
        this.isOnLeftBank = false;
        newGame(str);
    }

    @Override
    public String[] getInstructions() {
        return this.str.getInstructions();
    }

    @Override
    public List<ICrosser> getCrossersOnRightBank() {
        return (this.str.getType() == 1) ? ((Story1) this.str).getRightBankCrosser() : ((Story2) this.str).getRightBankCrosser();

    }

    @Override
    public List<ICrosser> getCrossersOnLeftBank() {
        return (this.str.getType() == 1) ? ((Story1) this.str).getLeftBankCrosser() : ((Story2) this.str).getLeftBankCrosser();
    }

    @Override
    public boolean isBoatOnTheLeftBank() {
        return this.isOnLeftBank;
    }

    @Override
    public int getNumberOfSails() {
        return this.numberOfSails;
    }

    @Override
    public boolean canMove(List<ICrosser> crossers, boolean fromLeftToRightBank) {
        List<ICrosser> tempRight = new ArrayList<ICrosser>();
        for(int i = 0; i < getCrossersOnRightBank().size(); i++)
            tempRight.add(getCrossersOnRightBank().get(i));

        List<ICrosser> tempLeft = new ArrayList<ICrosser>();
        for(int i = 0; i < getCrossersOnLeftBank().size(); i++)
            tempLeft.add(getCrossersOnLeftBank().get(i));
        
        if (fromLeftToRightBank) {
            for (int i = 0; i < crossers.size(); i++) {
                tempRight.add(crossers.get(i));
                tempLeft.remove(crossers.get(i));
            }
        } else {
            for (int i = 0; i < crossers.size(); i++) {
                tempRight.remove(crossers.get(i));
                tempLeft.add(crossers.get(i));
            }
        }
        return this.str.isValid(tempRight, tempLeft, crossers);
    }

    @Override
    public void doMove(List<ICrosser> crossers, boolean fromLeftToRightBank) {
        this.numberOfSails++;
        if (fromLeftToRightBank) {
            for (int i = 0; i < crossers.size(); i++) {
                if (str.getType() == 1) {
                    ((Story1) str).addRightBankCrosser(crossers.get(i));
                    ((Story1) str).removeLeftBankCrosser(crossers.get(i));

                } else if (str.getType() == 2) {
                    ((Story2) str).addRightBankCrosser(crossers.get(i));
                    ((Story2) str).removeLeftBankCrosser(crossers.get(i));
                }
            }
        } else {
            for (int i = 0; i < crossers.size(); i++) {
                if (str.getType() == 1) {
                    ((Story1) str).removeRightBankCrosser(crossers.get(i));
                    ((Story1) str).addLeftBankCrosser(crossers.get(i));

                } else if (str.getType() == 2) {
                    ((Story2) str).removeRightBankCrosser(crossers.get(i));
                    ((Story2) str).addLeftBankCrosser(crossers.get(i));
                }
            }
        }
        this.isOnLeftBank = (this.isOnLeftBank == false) ? true : false;
    }

    @Override
    public boolean canUndo() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean canRedo() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void undo() {
        if (this.canUndo()) {
        }
    }

    @Override
    public void redo() {
        if (this.canRedo()) {
        }
    }

    @Override
    public void saveGame() {
// xml
    }

    @Override
    public void loadGame() {
//xml
    }

    @Override
    public List<List<ICrosser>> solveGame() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public List<ICrosser> getCrossersOnBoat(ArrayList<Integer> x) {
        this.boatCrossers.clear();
        for (int i = 0; i < x.size(); i++) {
            this.boatCrossers.add((str.getInitialCrossers().get(x.get(i))));
        }
        return this.boatCrossers;
    }

    @Override
    public List<ICrosser> getCrossersOnBoat() {
        return this.boatCrossers;
    }

}
