
import java.util.ArrayList;
import java.util.List;



public class Story1 implements IcrossingStrategy {

    @Override
    public boolean isValid(List<ICrosser> right, List<ICrosser> left, List<ICrosser> boatRiders) {
        boolean valid = false;
        for (int i = 0; i < boatRiders.size(); i++) {
            ICrosser x = boatRiders.get(i);
            if (x.canSail()) {
                valid = true;
                break;
            }
        }
        if (valid == false) {
            return false;
        }
        if (left.size() == 3) {
            return false;
        } else if (left.size() == 2) {
            int diff=left.get(0).getEatingRank()-left.get(1).getEatingRank();
        if(diff==1 ||diff==-1)
            return false;
        }
        return true;
    }

    @Override
    public List<ICrosser> getInitialCrossers() {
        List<ICrosser> c = new ArrayList<>();
        Factory f = new Factory();
        c.add(new Farmer());
        c.add(new Carrot());
        c.add(new Cabbage());
        c.add(new Lion());
        c.add(new Fox());
        c.add(new Goat());
        c.add(new Donkey());
        c.add(f.getCrosser("Fox"));
        c.add(f.getCrosser("Lion"));
        c.add(f.getCrosser("Goat"));
        c.add(f.getCrosser("Donkey"));
        c.add(f.getCrosser("Cabbage"));
        c.add(f.getCrosser("Carrot"));
        c.add(f.getCrosser("Farmer"));

        return c;
    }

    @Override
    public String[] getInstructions() {
        String[] instructions = new String[100];
        instructions[0]="The farmer is the only one who can sail the boat/n";
        instructions[1]="The farmer can take only one passeneger in the boat/n";
        instructions[2]="you cannt leave any two crpsser who can harm each other/n";
        instructions[3]="carnevour can  harm a herbevour when left without a farmer.. /n";
        instructions[3]="herbevour can  harm a Plant when left without a farmer.. /n";
        instructions[3]="no body can harm a farmer.. /n";
   return instructions ; 
    } 

}
