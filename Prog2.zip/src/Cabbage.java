
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class Cabbage extends Plant {
     @Override
    public BufferedImage[] getImages() {
    BufferedImage c[]=new BufferedImage[2];
    
    
      for(int i = 0;i<2;i++){
    
    try{
      c[i] = ImageIO.read(new File(String.format("cabbage"+i+".png")));
              
        
        
    }
    catch(IOException e){
        
        
        
    }
    
    
    
    }
    
    
    
    
    
    return c;
    }
    
    
}
