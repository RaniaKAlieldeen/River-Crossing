
public class CarnivoreFactory extends AbstractFactory {

    @Override
    public Carnivore getCarnivoire(String cname) {
        if (cname.equals("Fox")) {
            return new Fox();
        }
        else
        return new Lion();
    }

    @Override
    public Harbivore getHarbivoire(String hname) {
        
         if (hname.equals("Goat")) {
            return new Goat();
        }
        else
        return new Donkey();
        
        
        
    }

    @Override
    public Plant getPlant(String pname) {
         if (pname.equals("Cabbage")) {
            return new Cabbage();
        }
        else
        return new Carrot();
        
        
        
        
       
    }



}
