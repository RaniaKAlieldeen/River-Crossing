
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;


class Goat extends Harbivore{

   
      @Override
    public BufferedImage[] getImages() {
    BufferedImage h[]=new BufferedImage[2];
    for(int i = 0;i<2;i++){
    
    try{
      h[i] = ImageIO.read(new File(String.format("goat"+i+".png")));
              
        
        
    }
    catch(IOException e){
        
        
        
    }
    
    
    
    }
    
    
   

    
    
    
    
    return h;
    
        
    }
    
}
