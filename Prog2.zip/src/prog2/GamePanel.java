/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package prog2;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.Timer;

public class GamePanel extends JPanel implements ActionListener {
    boolean left=true;
    int x = 0;
    Timer t = new Timer(100, this);
    boolean moveright = false;
    boolean moveleft = false;

    public GamePanel() {
        setBackground(Color.BLACK);
        t.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        ImageIcon farmer=null ;
        ImageIcon farmer1=null ;
        ImageIcon fox=null ;
        ImageIcon fox1=null ;
        ImageIcon lion=null ;
        ImageIcon lion1=null ;
        ImageIcon goat=null ;
        ImageIcon goat1=null ;
        ImageIcon Cabbage=null ;
        ImageIcon Cabbage1=null ;
        ImageIcon Carrot=null;
        ImageIcon Carrot1=null;
        ImageIcon donkey=null;
        ImageIcon donkey1=null;
        if(left==true){
        farmer= new ImageIcon("farmer.png");
       fox= new ImageIcon("fox.png");
       lion= new ImageIcon("lion.png");
       goat= new ImageIcon("goat.png");
       Cabbage= new ImageIcon("cabbage.png");
       Carrot= new ImageIcon("carrot.png");
       donkey= new ImageIcon("donkey.png");
       
               }
        else{
       farmer= new ImageIcon("farmer1.png");
       fox= new ImageIcon("fox1.png");
       lion= new ImageIcon("lion1.png");
       goat= new ImageIcon("goat1.png");
       Cabbage= new ImageIcon("cabbage1.png");
       Carrot= new ImageIcon("carrot1.png");
       donkey= new ImageIcon("donkey1.png");
        g.drawImage(farmer.getImage(), x, 10, this);
         g.drawImage(fox.getImage(), x, 15, this);
         g.drawImage(lion.getImage(), x, 15, this);
         g.drawImage(Cabbage.getImage(), x, 20, this);
         g.drawImage(Carrot.getImage(), x, 20, this);
         g.drawImage(donkey.getImage(), x, 25, this);
         g.drawImage(goat.getImage(), x, 25, this);
    }}

    @Override
    public void actionPerformed(ActionEvent e) {
        if (moveright == true) {
            if (x < 400) {
                x += 10;
                
            }else
                moveright=false;
        }
        
        
        else if  (moveleft == true) {
            if (x > 10) {
                x -= 10;
            }else
                moveleft=false;
        }
        
                repaint(); 
        
        
    }
    

    public void moveRight() {
        moveright = true;
    }

    public void moveLeft() {
         moveleft = true;
    }
}
