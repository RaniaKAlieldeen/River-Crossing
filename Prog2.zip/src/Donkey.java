
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author user
 */
public class Donkey extends Harbivore {
    
    public Donkey() {
    }

   @Override
    public BufferedImage[] getImages() {
    BufferedImage h[]=new BufferedImage[2];
    
    
    
    
      for(int i = 0;i<2;i++){
    
    try{
      h[i] = ImageIO.read(new File(String.format("donkey"+i+".png")));
              
        
        
    }
    catch(IOException e){
        
        
        
    }
    
    
    
    }
    
    
    
    
    
    return h;
    }
    
}
