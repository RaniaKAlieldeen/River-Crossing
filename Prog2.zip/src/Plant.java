
import java.awt.image.BufferedImage;


public class Plant implements ICrosser{

    @Override
    public boolean canSail() {
       return false;
    }

    @Override
    public int getEatingRank() {
      return 3;
    }

    @Override
    public BufferedImage[] getImages() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
