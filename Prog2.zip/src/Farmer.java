
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class Farmer implements ICrosser {

    @Override
    public boolean canSail() {
        return true;
    }

    @Override
    public int getEatingRank() {
       return 10;
    }

    @Override
    public BufferedImage[] getImages() {
       
       
    BufferedImage f[]=new BufferedImage[2];
        
    for(int i = 0;i<2;i++){
    
    try{
      f[i] = ImageIO.read(new File(String.format("farmer"+i+".png")));
              
        
        
    }
    catch(IOException e){
        
        
        
    }
    
    
    
    }    
    
    
    
    
    
    
return f;

}}
